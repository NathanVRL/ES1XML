package com.example;

import java.util.ArrayList;

public class Studenti {
    ArrayList <Studente>studente=new ArrayList<>();

    public Studenti(ArrayList<Studente> studente) {
        this.studente = studente;

    }

    public Studenti() {
    }

    public ArrayList<Studente> getStudente() {
        return studente;
    }

    public void setStudente(ArrayList<Studente> studente) {
        this.studente = studente;
    }
    public void addStudenti(Studente c){
        studente.add(c);
    }
    
}

