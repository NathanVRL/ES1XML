package com.example;

public class Studente {
    private int id,votoesame ;
    private String cognome,nome,datanascita;
    public int getId() {
        return id;
    }
    public int getVotoesame() {
        return votoesame;
    }
    public void setVotoesame(int votoesame) {
        this.votoesame = votoesame;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getCognome() {
        return cognome;
    }
    public void setCognome(String cognome) {
        this.cognome = cognome;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getDatanascita() {
        return datanascita;
    }
    public void setDatanascita(String datanascita) {
        this.datanascita = datanascita;
    }

    
    
    public Studente(int id, String cognome, String nome, String datanascita,int votoesame) {
        this.id = id;
        this.cognome = cognome;
        this.nome = nome;
        this.datanascita = datanascita;
        this.votoesame=votoesame;
    }
    public Studente() {
    }
}
