package com.example;
import java.io.File;
import java.util.ArrayList;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws Exception 
    {
        ArrayList <Studente>studente=new ArrayList<>();
        System.out.println("------------");
        Studente Giuseppe = new Studente(1,"Verdi", "Giuseppe","2005-03-12",90);
        Studente Giacomo = new Studente(1,"Puccini", "Giacomo","2005-06-11",92);
        Studente Grazia = new Studente(1,"Deledda", "Grazia","2005-09-14",100);
        Studente Arrigo = new Studente(1,"Boito", "Arrigo","2004-11-13",88);
        studente.add(Giuseppe);
        studente.add(Giacomo);
        studente.add(Grazia);
        studente.add(Arrigo);
        Studenti c1=new Studenti(studente);
        XmlMapper xmlMapper = new XmlMapper();
        
        // Serializzazione        
        xmlMapper.writeValue(new File("test.xml"), c1);
        String myXml = xmlMapper.writeValueAsString(c1);
        System.out.println("Oggetto serializzato:" + myXml);
        
        //  Deserializzazione        
        Studenti c2 = xmlMapper.readValue(myXml, Studenti.class);
        System.out.println("Oggetto deserializzato " );

        Studenti c3 = xmlMapper.readValue(new File("test.xml"), Studenti.class);
        System.out.println("Oggetto deserializzato " );
    }


}
